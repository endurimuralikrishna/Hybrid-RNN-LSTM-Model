# Data access
Source: https://www.kaggle.com/datasets/infamouscoder/depression-reddit-cleaned
No original records are included. Verify license, Reddit terms, consent provenance and institutional ethics requirements before access or redistribution. Public availability is not permission. Download locally using download_data.py only after verification. Inspect CSV headers and documented label meanings before running. Do not publish raw posts, identifiers, or individual predictions. The example CSV is fictional and only demonstrates the expected schema.
